"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_event-detail_event-detail_module_ts"],{

/***/ 98:
/*!*************************************************************!*\
  !*** ./src/app/event-detail/event-detail-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventDetailPageRoutingModule": () => (/* binding */ EventDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _event_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./event-detail.page */ 5459);




const routes = [
    {
        path: '',
        component: _event_detail_page__WEBPACK_IMPORTED_MODULE_0__.EventDetailPage
    }
];
let EventDetailPageRoutingModule = class EventDetailPageRoutingModule {
};
EventDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EventDetailPageRoutingModule);



/***/ }),

/***/ 9314:
/*!*****************************************************!*\
  !*** ./src/app/event-detail/event-detail.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventDetailPageModule": () => (/* binding */ EventDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _event_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./event-detail-routing.module */ 98);
/* harmony import */ var _event_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./event-detail.page */ 5459);







let EventDetailPageModule = class EventDetailPageModule {
};
EventDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _event_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.EventDetailPageRoutingModule
        ],
        declarations: [_event_detail_page__WEBPACK_IMPORTED_MODULE_1__.EventDetailPage]
    })
], EventDetailPageModule);



/***/ }),

/***/ 5459:
/*!***************************************************!*\
  !*** ./src/app/event-detail/event-detail.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventDetailPage": () => (/* binding */ EventDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _event_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./event-detail.page.html?ngResource */ 8836);
/* harmony import */ var _event_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./event-detail.page.scss?ngResource */ 8379);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let EventDetailPage = class EventDetailPage {
    constructor() {
        //Header Start
        this.searchValue = "";
        this.searchableItems = {
            'Oct 8 Milad un Nabi (Mawlid), Muslim': 'event-detail',
            'Oct 10 First day of Sukkot, Jewish Holiday': 'event-detail',
            'Oct 10 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 11 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 12 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 13 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 14 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 15 Thanksgiving Day, Statutory Holiday': 'event-detail',
        };
        this.displaySearchableItems = {};
        this.searchListener = () => {
            //turn off suggestion drop-down list when list is empty
            this.displaySearchableItems = {};
            //When search input is blank
            if (!this.searchValue || !this.searchValue.trim()) {
                return;
            }
            for (const key in this.searchableItems) {
                //.replace(/ /g, "") to remove space
                if (key.replace(/ /g, "").toUpperCase().includes(this.searchValue.trim().replace(/ /g, "").toUpperCase())) {
                    this.displaySearchableItems[key] = this.searchableItems[key];
                }
            }
            if (Object.keys(this.displaySearchableItems).length === 0) {
                this.displaySearchableItems = { 'Cannot find a matching event': '' };
            }
        };
    }
    // constructor() { }
    ngOnInit() {
    }
};
EventDetailPage.ctorParameters = () => [];
EventDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-event-detail',
        template: _event_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_event_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EventDetailPage);



/***/ }),

/***/ 8379:
/*!****************************************************************!*\
  !*** ./src/app/event-detail/event-detail.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n#header {\n  font-size: 30px;\n  margin: auto;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n\nion-header {\n  background-color: #222222;\n}\n\n#navigation {\n  width: -moz-fit-content;\n  width: fit-content;\n  margin: auto;\n  margin-bottom: 5px;\n}\n\n#searchBar {\n  display: inline-block;\n  padding-left: 0px;\n  width: 300px;\n}\n\n.navi-button {\n  margin-right: 30px;\n}\n\n#event-table {\n  border: 1px solid white;\n}\n\n.center {\n  text-align: center;\n}\n\na {\n  text-decoration: none;\n}\n\n#searchSuggestion {\n  display: block;\n  margin-left: 7px;\n  width: 300px;\n  overflow-y: scroll;\n  font-size: 16px;\n  position: absolute;\n  z-index: 100;\n  opacity: 100%;\n  background-color: #373737;\n  max-height: 150px;\n}\n\n.suggestedItems {\n  padding: 8px;\n  margin-bottom: 2px;\n  color: white;\n  width: 100%;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.suggestedItems:hover {\n  background-color: #292929;\n}\n\n#searchEventBar:focus {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV2ZW50LWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7QUFDSjs7QUFFQTtFQUNJLHFCQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUFBLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSx5QkFBQTtBQUNKOztBQUVBO0VBQ0ksdUJBQUE7RUFBQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0kscUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSx1QkFBQTtBQUNKOztBQUVBO0VBQ0ksa0JBQUE7QUFDSjs7QUFFQTtFQUNJLHFCQUFBO0FBQ0o7O0FBRUE7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7QUFDSjs7QUFFQTtFQUNJLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBQ0o7O0FBRUE7RUFDSSx5QkFBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtBQUNKIiwiZmlsZSI6ImV2ZW50LWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICByaWdodDogMDtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xyXG59XHJcblxyXG4jY29udGFpbmVyIHN0cm9uZyB7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjZweDtcclxufVxyXG5cclxuI2NvbnRhaW5lciBwIHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xyXG4gICAgY29sb3I6ICM4YzhjOGM7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbiNjb250YWluZXIgYSB7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuXHJcbiNoZWFkZXIge1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICB3aWR0aDogZml0LWNvbnRlbnQ7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzIyMjIyMjtcclxufVxyXG5cclxuI25hdmlnYXRpb24ge1xyXG4gICAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG59XHJcblxyXG4jc2VhcmNoQmFyIHtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHBhZGRpbmctbGVmdDogMHB4O1xyXG4gICAgd2lkdGg6IDMwMHB4O1xyXG59XHJcblxyXG4ubmF2aS1idXR0b24ge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xyXG59XHJcblxyXG4jZXZlbnQtdGFibGUge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XHJcbn1cclxuXHJcbi5jZW50ZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG5hIHtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG5cclxuI3NlYXJjaFN1Z2dlc3Rpb24ge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBtYXJnaW4tbGVmdDogN3B4O1xyXG4gICAgd2lkdGg6IDMwMHB4O1xyXG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgei1pbmRleDogMTAwO1xyXG4gICAgb3BhY2l0eTogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMzNzM3Mzc7XHJcbiAgICBtYXgtaGVpZ2h0OiAxNTBweDtcclxufVxyXG5cclxuLnN1Z2dlc3RlZEl0ZW1zIHtcclxuICAgIHBhZGRpbmc6IDhweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDJweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG5cclxuLnN1Z2dlc3RlZEl0ZW1zOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMyOTI5Mjk7XHJcbn1cclxuXHJcbiNzZWFyY2hFdmVudEJhcjpmb2N1cyB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG59Il19 */";

/***/ }),

/***/ 8836:
/*!****************************************************************!*\
  !*** ./src/app/event-detail/event-detail.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<!-- NEED TO MAKE THE HEADER PART A SEPARATE COMPONENT WITH CSS AND JS -->\r\n<ion-header [translucent]=\"true\">\r\n    <div>\r\n        <div id=\"header\">\r\n            Our Cultures - The App\r\n        </div>\r\n        <div id=\"navigation\">\r\n            <a href=\"\" class=\"navi-button\">Home</a>\r\n            <a href=\"\" class=\"navi-button\">Popular Events</a>\r\n            <a href=\"\" class=\"navi-button\" [routerLink]=\"['/login']\">Contribute</a>\r\n            <div id=\"searchBar\">\r\n                <ion-searchbar [(ngModel)]=\"searchValue\" (ngModelChange)=\"searchListener()\" id=\"searchEventBar\"></ion-searchbar>\r\n                <div class=\"ion-card\" id=\"searchSuggestion\">\r\n                    <a *ngFor=\"let i of displaySearchableItems | keyvalue\" [routerLink]=\"['/'+i.value]\">\r\n                        <div class=\"suggestedItems\">{{ i.key }}</div>\r\n                    </a>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</ion-header>\r\n\r\n\r\n<ion-content [fullscreen]=\"true\">\r\n    <br>\r\n    <ion-grid style=\"width: 60%;\" id=\"event-table\">\r\n        <ion-row style=\"background-color: white; color: black;\">\r\n            <ion-col style=\"margin-top: 10px;\">Event Name</ion-col>\r\n            <ion-col style=\"margin-top: 10px;\">Labour Day</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>Date of Next Event: </ion-col>\r\n            <ion-col>September 5, 2022</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>Same data every year: (If no, how is it calculated)</ion-col>\r\n            <ion-col>No</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>Religious/Non-Religious?</ion-col>\r\n            <ion-col>No</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>Type of Event</ion-col>\r\n            <ion-col>Statutory Holiday</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>Where in Canada Observed</ion-col>\r\n            <ion-col>Observed across Canada. Schools and most businesses are closed</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>Reasons</ion-col>\r\n            <ion-col>This holiday marks the change from summer vacation to the beginning of a new school year in September.</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>What do people do?</ion-col>\r\n            <ion-col>Many families with children return from holidays, and a new back-to-school seriousness sets in for September. People usually relax, have last-opportunity summer parties, and prepare for colder months of Fall and Winter season.</ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_event-detail_event-detail_module_ts.js.map