"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 5089:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 9460);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 2711:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 9460);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 5089);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 9460:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page.html?ngResource */ 3853);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 1020);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let HomePage = class HomePage {
    constructor() {
        this.searchValue = "";
        this.searchableItems = {
            'Oct 8 Milad un Nabi (Mawlid), Muslim': 'event-detail',
            'Oct 10 First day of Sukkot, Jewish Holiday': 'event-detail',
            'Oct 10 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 11 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 12 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 13 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 14 Thanksgiving Day, Statutory Holiday': 'event-detail',
            'Oct 15 Thanksgiving Day, Statutory Holiday': 'event-detail',
        };
        this.displaySearchableItems = {};
        this.searchListener = () => {
            //turn off suggestion drop-down list when list is empty
            this.displaySearchableItems = {};
            //When search input is blank
            if (!this.searchValue || !this.searchValue.trim()) {
                return;
            }
            for (const key in this.searchableItems) {
                //.replace(/ /g, "") to remove space
                if (key.replace(/ /g, "").toUpperCase().includes(this.searchValue.trim().replace(/ /g, "").toUpperCase())) {
                    this.displaySearchableItems[key] = this.searchableItems[key];
                }
            }
            if (Object.keys(this.displaySearchableItems).length === 0) {
                this.displaySearchableItems = { 'Cannot find a matching event': '' };
            }
        };
    }
};
HomePage.ctorParameters = () => [];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-home',
        template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 1020:
/*!************************************************!*\
  !*** ./src/app/home/home.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n#header {\n  font-size: 30px;\n  margin: auto;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n\nion-header {\n  background-color: #222222;\n}\n\n#navigation {\n  width: -moz-fit-content;\n  width: fit-content;\n  margin: auto;\n  margin-bottom: 5px;\n}\n\n#searchBar {\n  display: inline-block;\n  padding-left: 0px;\n  width: 300px;\n}\n\n.navi-button {\n  margin-right: 30px;\n}\n\n#calendar-table {\n  border: 1px solid white;\n}\n\n.center {\n  text-align: center;\n}\n\na {\n  text-decoration: none;\n}\n\n#searchSuggestion {\n  display: block;\n  margin-left: 7px;\n  width: 300px;\n  overflow-y: scroll;\n  font-size: 16px;\n  position: absolute;\n  z-index: 100;\n  opacity: 100%;\n  background-color: #373737;\n  max-height: 150px;\n}\n\n.suggestedItems {\n  padding: 8px;\n  margin-bottom: 2px;\n  color: white;\n  width: 100%;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.suggestedItems:hover {\n  background-color: #292929;\n}\n\n#searchEventBar:focus {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBQ0o7O0FBRUE7RUFDSSxxQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFBQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0kseUJBQUE7QUFDSjs7QUFFQTtFQUNJLHVCQUFBO0VBQUEsa0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFDSjs7QUFFQTtFQUNJLHFCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksdUJBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxxQkFBQTtBQUNKOztBQUVBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQUNKOztBQUVBO0VBQ0kseUJBQUE7QUFDSjs7QUFFQTtFQUNJLGFBQUE7QUFDSiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNjb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDUwJTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XG59XG5cbiNjb250YWluZXIgcCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgIGNvbG9yOiAjOGM4YzhjO1xuICAgIG1hcmdpbjogMDtcbn1cblxuI2NvbnRhaW5lciBhIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbiNoZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIHdpZHRoOiBmaXQtY29udGVudDtcbn1cblxuaW9uLWhlYWRlciB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzIyMjIyMjtcbn1cblxuI25hdmlnYXRpb24ge1xuICAgIHdpZHRoOiBmaXQtY29udGVudDtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuXG4jc2VhcmNoQmFyIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgcGFkZGluZy1sZWZ0OiAwcHg7XG4gICAgd2lkdGg6IDMwMHB4O1xufVxuXG4ubmF2aS1idXR0b24ge1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbn1cblxuI2NhbGVuZGFyLXRhYmxlIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbn1cblxuLmNlbnRlciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5hIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbiNzZWFyY2hTdWdnZXN0aW9uIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBtYXJnaW4tbGVmdDogN3B4O1xuICAgIHdpZHRoOiAzMDBweDtcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiAxMDA7XG4gICAgb3BhY2l0eTogMTAwJTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzczNzM3O1xuICAgIG1heC1oZWlnaHQ6IDE1MHB4O1xufVxuXG4uc3VnZ2VzdGVkSXRlbXMge1xuICAgIHBhZGRpbmc6IDhweDtcbiAgICBtYXJnaW4tYm90dG9tOiAycHg7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbn1cblxuLnN1Z2dlc3RlZEl0ZW1zOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjkyOTI5O1xufVxuXG4jc2VhcmNoRXZlbnRCYXI6Zm9jdXMge1xuICAgIGRpc3BsYXk6IG5vbmU7XG59Il19 */";

/***/ }),

/***/ 3853:
/*!************************************************!*\
  !*** ./src/app/home/home.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<!-- NEED TO MAKE THE HEADER PART A SEPARATE COMPONENT WITH CSS AND JS -->\r\n<ion-header [translucent]=\"true\">\r\n    <div>\r\n        <div id=\"header\">\r\n            Our Cultures - The App\r\n        </div>\r\n        <div id=\"navigation\">\r\n            <a href=\"\" class=\"navi-button\">Home</a>\r\n            <a href=\"\" class=\"navi-button\">Popular Events</a>\r\n            <a href=\"\" class=\"navi-button\" [routerLink]=\"['/login']\">Contribute</a>\r\n            <div id=\"searchBar\">\r\n                <ion-searchbar [(ngModel)]=\"searchValue\" (ngModelChange)=\"searchListener()\" id=\"searchEventBar\"></ion-searchbar>\r\n                <div class=\"ion-card\" id=\"searchSuggestion\">\r\n                    <a *ngFor=\"let i of displaySearchableItems | keyvalue\" [routerLink]=\"['/'+i.value]\">\r\n                        <div class=\"suggestedItems\">{{ i.key }}</div>\r\n                    </a>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</ion-header>\r\n\r\n<ion-content [fullscreen]=\"true\">\r\n    <br>\r\n    <ion-grid style=\"width: 80%;\">\r\n        <ion-row>\r\n            <ion-col size=\"8\">\r\n\r\n                <div style=\"width:fit-content;margin: auto;\">\r\n                    <ion-button color=\"dark\">Monthly</ion-button>\r\n                    <ion-button color=\"dark\">Weekly</ion-button>\r\n                </div>\r\n                <ion-grid id=\"calendar-table\">\r\n                    <ion-row style=\"background-color: white; color: black;\">\r\n                        <ion-col class=\"center\" style=\"margin-top: 10px;\">September</ion-col>\r\n                        <ion-col class=\"center\">\r\n                            <ion-select interface=\"popover\" placeholder=\"Oct\" style=\"width: 90px; margin: auto; --placeholder-color: black; --placeholder-opacity: 1;\">\r\n                                <ion-select-option>Jan</ion-select-option>\r\n                                <ion-select-option>Feb</ion-select-option>\r\n                                <ion-select-option>Mar</ion-select-option>\r\n                                <ion-select-option>Apr</ion-select-option>\r\n                                <ion-select-option>May</ion-select-option>\r\n                                <ion-select-option>Jun</ion-select-option>\r\n                                <ion-select-option>Jul</ion-select-option>\r\n                                <ion-select-option>Aug</ion-select-option>\r\n                                <ion-select-option>Sep</ion-select-option>\r\n                                <ion-select-option>Oct</ion-select-option>\r\n                                <ion-select-option>Nov</ion-select-option>\r\n                                <ion-select-option>Dec</ion-select-option>\r\n                            </ion-select>\r\n                        </ion-col>\r\n                        <ion-col class=\"center\">\r\n                            <ion-select interface=\"popover\" placeholder=\"2022\" style=\"width: 90px; margin: auto; --placeholder-color: black; --placeholder-opacity: 1;\">\r\n                                <ion-select-option>2021</ion-select-option>\r\n                                <ion-select-option>2023</ion-select-option>\r\n                            </ion-select>\r\n                        </ion-col>\r\n                        <ion-col class=\"center\" style=\"margin-top: 10px;\">November</ion-col>\r\n                    </ion-row>\r\n                    <ion-grid style=\"width: 80%;\">\r\n                        <ion-row>\r\n                            <ion-col class=\"center\">Sun</ion-col>\r\n                            <ion-col class=\"center\">Mon</ion-col>\r\n                            <ion-col class=\"center\">Tue</ion-col>\r\n                            <ion-col class=\"center\">Wed</ion-col>\r\n                            <ion-col class=\"center\">Thu</ion-col>\r\n                            <ion-col class=\"center\">Fri</ion-col>\r\n                            <ion-col class=\"center\">Sat</ion-col>\r\n                        </ion-row>\r\n\r\n                        <ion-row>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\">\r\n                                <p style=\"border-bottom: 2px solid rgb(67, 67, 199); width: 30px; margin: auto;\">1</p>\r\n                            </ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col class=\"center\">2</ion-col>\r\n                            <ion-col class=\"center\">3</ion-col>\r\n                            <ion-col class=\"center\">4</ion-col>\r\n                            <ion-col class=\"center\">5</ion-col>\r\n                            <ion-col class=\"center\">6</ion-col>\r\n                            <ion-col class=\"center\">7</ion-col>\r\n                            <ion-col class=\"center\">8</ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col class=\"center\">9</ion-col>\r\n                            <ion-col class=\"center\">10</ion-col>\r\n                            <ion-col class=\"center\">11</ion-col>\r\n                            <ion-col class=\"center\">12</ion-col>\r\n                            <ion-col class=\"center\">13</ion-col>\r\n                            <ion-col class=\"center\">14</ion-col>\r\n                            <ion-col class=\"center\">15</ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col class=\"center\">16</ion-col>\r\n                            <ion-col class=\"center\">17</ion-col>\r\n                            <ion-col class=\"center\">18</ion-col>\r\n                            <ion-col class=\"center\">19</ion-col>\r\n                            <ion-col class=\"center\">20</ion-col>\r\n                            <ion-col class=\"center\">21</ion-col>\r\n                            <ion-col class=\"center\">22</ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col class=\"center\">23</ion-col>\r\n                            <ion-col class=\"center\">24</ion-col>\r\n                            <ion-col class=\"center\">25</ion-col>\r\n                            <ion-col class=\"center\">26</ion-col>\r\n                            <ion-col class=\"center\">27</ion-col>\r\n                            <ion-col class=\"center\">28</ion-col>\r\n                            <ion-col class=\"center\">29</ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col class=\"center\">30</ion-col>\r\n                            <ion-col class=\"center\">31</ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                            <ion-col class=\"center\"></ion-col>\r\n                        </ion-row>\r\n                    </ion-grid>\r\n                </ion-grid>\r\n\r\n            </ion-col>\r\n            <ion-col size=\"4\" style=\"padding-left: 20px;\">\r\n                <b style=\"display:inline-block;margin-top: 10px; width: fit-content;\"> Events in the coming week</b>\r\n                <ion-select interface=\"popover\" placeholder=\"All events \" style=\"width: 110px; margin: auto; --placeholder-color: white; --placeholder-opacity: 1; float: right; background-color: grey; \">\r\n                    <ion-select-option>Observance</ion-select-option>\r\n                    <ion-select-option>Christian</ion-select-option>\r\n                    <ion-select-option>Muslims</ion-select-option>\r\n                    <ion-select-option>Budish</ion-select-option>\r\n                    <ion-select-option>Indian</ion-select-option>\r\n                </ion-select>\r\n                <br>\r\n                <a [routerLink]=\"['/event-detail']\">Oct 8 Milad un Nabi (Mawlid), Muslim</a> <br>\r\n                <a [routerLink]=\"['/event-detail']\">Oct 10 First day of Sukkot, Jewish Holiday</a> <br>\r\n                <a [routerLink]=\"['/event-detail']\">Oct 10 Thanksgiving Day, Statutory Holiday</a> <br>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map