"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_server-down_server-down_module_ts"],{

/***/ 7821:
/*!***********************************************************!*\
  !*** ./src/app/server-down/server-down-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServerDownPageRoutingModule": () => (/* binding */ ServerDownPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _server_down_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./server-down.page */ 1481);




const routes = [
    {
        path: '',
        component: _server_down_page__WEBPACK_IMPORTED_MODULE_0__.ServerDownPage
    }
];
let ServerDownPageRoutingModule = class ServerDownPageRoutingModule {
};
ServerDownPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ServerDownPageRoutingModule);



/***/ }),

/***/ 6885:
/*!***************************************************!*\
  !*** ./src/app/server-down/server-down.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServerDownPageModule": () => (/* binding */ ServerDownPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _server_down_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./server-down-routing.module */ 7821);
/* harmony import */ var _server_down_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./server-down.page */ 1481);







let ServerDownPageModule = class ServerDownPageModule {
};
ServerDownPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _server_down_routing_module__WEBPACK_IMPORTED_MODULE_0__.ServerDownPageRoutingModule
        ],
        declarations: [_server_down_page__WEBPACK_IMPORTED_MODULE_1__.ServerDownPage]
    })
], ServerDownPageModule);



/***/ }),

/***/ 1481:
/*!*************************************************!*\
  !*** ./src/app/server-down/server-down.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServerDownPage": () => (/* binding */ ServerDownPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _server_down_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./server-down.page.html?ngResource */ 17);
/* harmony import */ var _server_down_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./server-down.page.scss?ngResource */ 766);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let ServerDownPage = class ServerDownPage {
    constructor() { }
    ngOnInit() {
    }
};
ServerDownPage.ctorParameters = () => [];
ServerDownPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-server-down',
        template: _server_down_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_server_down_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ServerDownPage);



/***/ }),

/***/ 766:
/*!**************************************************************!*\
  !*** ./src/app/server-down/server-down.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n#header {\n  font-size: 30px;\n  margin: auto;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n\nion-header {\n  background-color: #222222;\n}\n\n#navigation {\n  width: -moz-fit-content;\n  width: fit-content;\n  margin: auto;\n  margin-bottom: 5px;\n}\n\n#searchBar {\n  display: inline-block;\n  padding-left: 0px;\n  width: 300px;\n}\n\n.navi-button {\n  margin-right: 30px;\n}\n\n#calendar-table {\n  border: 1px solid white;\n}\n\n.center {\n  text-align: center;\n}\n\na {\n  text-decoration: none;\n}\n\n#searchSuggestion {\n  display: block;\n  margin-left: 7px;\n  width: 300px;\n  overflow-y: scroll;\n  font-size: 16px;\n  position: absolute;\n  z-index: 100;\n  opacity: 100%;\n  background-color: #373737;\n  max-height: 150px;\n}\n\n.suggestedItems {\n  padding: 8px;\n  margin-bottom: 2px;\n  color: white;\n  width: 100%;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.suggestedItems:hover {\n  background-color: #292929;\n}\n\n#searchEventBar:focus {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZlci1kb3duLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQUNKOztBQUVBO0VBQ0kscUJBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQUEsa0JBQUE7QUFDSjs7QUFFQTtFQUNJLHlCQUFBO0FBQ0o7O0FBRUE7RUFDSSx1QkFBQTtFQUFBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVBO0VBQ0ksa0JBQUE7QUFDSjs7QUFFQTtFQUNJLHVCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtBQUNKOztBQUVBO0VBQ0kscUJBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUVBO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUFDSjs7QUFFQTtFQUNJLHlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxhQUFBO0FBQ0oiLCJmaWxlIjoic2VydmVyLWRvd24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2NvbnRhaW5lciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxufVxyXG5cclxuI2NvbnRhaW5lciBzdHJvbmcge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XHJcbn1cclxuXHJcbiNjb250YWluZXIgcCB7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjJweDtcclxuICAgIGNvbG9yOiAjOGM4YzhjO1xyXG4gICAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4jY29udGFpbmVyIGEge1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG59XHJcblxyXG4jaGVhZGVyIHtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG59XHJcblxyXG5pb24taGVhZGVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMyMjIyMjI7XHJcbn1cclxuXHJcbiNuYXZpZ2F0aW9uIHtcclxuICAgIHdpZHRoOiBmaXQtY29udGVudDtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxufVxyXG5cclxuI3NlYXJjaEJhciB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDBweDtcclxuICAgIHdpZHRoOiAzMDBweDtcclxufVxyXG5cclxuLm5hdmktYnV0dG9uIHtcclxuICAgIG1hcmdpbi1yaWdodDogMzBweDtcclxufVxyXG5cclxuI2NhbGVuZGFyLXRhYmxlIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xyXG59XHJcblxyXG4uY2VudGVyIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuYSB7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuXHJcbiNzZWFyY2hTdWdnZXN0aW9uIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDdweDtcclxuICAgIHdpZHRoOiAzMDBweDtcclxuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHotaW5kZXg6IDEwMDtcclxuICAgIG9wYWNpdHk6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzczNzM3O1xyXG4gICAgbWF4LWhlaWdodDogMTUwcHg7XHJcbn1cclxuXHJcbi5zdWdnZXN0ZWRJdGVtcyB7XHJcbiAgICBwYWRkaW5nOiA4cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAycHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbn1cclxuXHJcbi5zdWdnZXN0ZWRJdGVtczpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjkyOTI5O1xyXG59XHJcblxyXG4jc2VhcmNoRXZlbnRCYXI6Zm9jdXMge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufSJdfQ== */";

/***/ }),

/***/ 17:
/*!**************************************************************!*\
  !*** ./src/app/server-down/server-down.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<!-- NEED TO MAKE THE HEADER PART A SEPARATE COMPONENT WITH CSS AND JS -->\n<ion-header [translucent]=\"true\">\n    <div>\n        <div id=\"header\">\n            Our Cultures - The App\n        </div>\n        <div id=\"navigation\">\n            <a href=\"\" class=\"navi-button\">Home</a>\n            <a href=\"\" class=\"navi-button\">Popular Events</a>\n            <a href=\"\" class=\"navi-button\" [routerLink]=\"['/login']\">Contribute</a>\n        </div>\n    </div>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n    <br>\n    <div style=\"width: 50%; margin: auto;\">\n        <ion-card>\n            <ion-card-header color=\"danger\">\n                <ion-card-title>Warning</ion-card-title>\n            </ion-card-header>\n\n            <ion-card-content class=\"ion-text-center\">\n                <br>\n                <ion-card-title>Server temporarilly unavailable</ion-card-title>\n                <ion-icon style=\"font-size: 100px; display: block;margin: auto;\" name=\"warning\"></ion-icon>\n                Please contact with info@ourculturetheapp.com to get more information\n            </ion-card-content>\n        </ion-card>\n    </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_server-down_server-down_module_ts.js.map